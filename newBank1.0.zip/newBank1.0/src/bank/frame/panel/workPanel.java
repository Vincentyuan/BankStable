package bank.frame.panel;

import javax.swing.JPanel;

import bank.frame.MainFrame;

public abstract class workPanel extends JPanel implements workInterface {

	@Override
	public void init() throws Exception {
		// TODO Auto-generated method stub

	}
	public void setLocation(){
		
	}
	
	public void setFrame(MainFrame frame){
		
	}

}
