package bank.frame.panel;

public class controlPanel extends workPanel{
	
	private workPanel [] work;

	public controlPanel(){
		work =new workPanel [6];
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
