package bank.frame.panel;

public interface workInterface {

	public void init() throws Exception;
}
