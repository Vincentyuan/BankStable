package bank.frame;

public class ClientContext {

	
	public static String name;

	public ClientContext(){
		
		
	}
	
	private void loadLogon(){
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void setUserName(String name) {
		// TODO Auto-generated method stub
		this.name=name;
	}

	public String getUserName() {
		// TODO Auto-generated method stub
		return this.name;
	}

}
