package bank.util;

import java.util.HashMap;
import java.util.Map;

import bank.judge.MaxMinValue;

public class runTimeInfor {
	//��½������½ʱ��
	private String logonName;
	
	private static Map<Integer, MaxMinValue> maxMin=new HashMap<Integer, MaxMinValue>();

	public void computeMaxMin(){

	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
