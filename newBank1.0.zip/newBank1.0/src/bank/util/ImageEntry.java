package bank.util;

public class ImageEntry {

	private String bankName;
	private String year;
	private String imageName;
	private int [] abscissa;//������
	private double [] ordinate;//������
	public ImageEntry() {
		// TODO Auto-generated constructor stub
	}
	
	
	

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}




	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}




	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}




	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}




	/**
	 * @return the imageName
	 */
	public String getImageName() {
		return imageName;
	}




	/**
	 * @param imageName the imageName to set
	 */
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}




	/**
	 * @return the abscissa
	 */
	public int[] getAbscissa() {
		return abscissa;
	}




	/**
	 * @param abscissa the abscissa to set
	 */
	public void setAbscissa(int[] abscissa) {
		this.abscissa = abscissa;
	}




	/**
	 * @return the ordinate
	 */
	public double [] getOrdinate() {
		return ordinate;
	}




	/**
	 * @param ordinate the ordinate to set
	 */
	public void setOrdinate(double [] ordinate) {
		this.ordinate = ordinate;
	}




	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
