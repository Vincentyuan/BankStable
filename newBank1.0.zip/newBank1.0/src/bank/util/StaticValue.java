package bank.util;

public class StaticValue {
	
	static public int i=0;
	static private String imageRootFolder="image";

	public StaticValue() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
