/**
 * 
 */
/**
 * @author yuanping
 *
 */
package bank.judge.entity;