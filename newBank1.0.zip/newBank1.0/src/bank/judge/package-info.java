/**
 * 
 */
/**
 * @author yuanping
 *
 */
package bank.judge;

/*
 * 
 * used for save the whole data to compute.
 */