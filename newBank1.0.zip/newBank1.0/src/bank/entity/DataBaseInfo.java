package bank.entity;

public class DataBaseInfo {

	private String tableName;
	
	public DataBaseInfo() {
		// TODO Auto-generated constructor stub
	}

}
