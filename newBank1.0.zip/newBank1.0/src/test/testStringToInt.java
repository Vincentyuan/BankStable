package test;

public class testStringToInt {

	public testStringToInt() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String nameString="111";
		Integer integer=Integer.valueOf(nameString);
		System.out.println(integer);
	}

}
