package test;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import org.jfree.chart.axis.CategoryAxis;

import bank.dao.NatDebtRateDao;
import bank.dao.NatDebtRateImpl;
import bank.entity.NatDebtRate;

public class testE {

	public testE() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		CategoryAxis catalog=new CategoryAxis();
		
	}

}
